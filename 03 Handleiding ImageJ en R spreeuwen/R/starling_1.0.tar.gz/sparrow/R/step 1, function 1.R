#### function 1 
listbirdfiles <- function(direcPictures){
  allFiles=list.files(path=paste(direcPictures,sep='')) 
  allFiles=as.matrix(allFiles); 
  return(allFiles) # list images
}
