#### function 2
setThreshold <- function(image_to_open,Threshold){
  # opening specific image
  allFiles=list.files(path=paste(direcPictures,sep='')) 
  allFiles=as.matrix(allFiles); 
  a=as.integer(image_to_open)
  imagename=allFiles[a,]
  image=readImage(paste(direcPictures,'/',imagename,sep=''))
  image1=image[,,1]; image2=image[,,2]; image3=image[,,3]
  # threshold certain layer automatic (most clear layer picked automatically as well)
  med1=sd(image1);med2=sd(image2);med3=sd(image3);
  medtot=cbind(med1,med2,med3); medmax=min(medtot); framenr=which(medtot[1,]==medmax)
  normalize(image[,,framenr], separate=TRUE, ft=c(0,1));
  image1=image[,,framenr]; image1org=image[,,framenr]
  dimimage=(dim(image1)); dimimage=as.matrix(dimimage); t=dimimage[2,]
  meet1=t/2; meet11=round(meet1, digits = 0)
  meet2=t/4; meet12=round(meet2, digits = 0)
  meet3=(t/4)*3; meet13=round(meet3, digits = 0)
  meet4=t/5; meet14=round(meet4, digits = 0)
  meet5=t/6; meet15=round(meet5, digits = 0)
  row1=mean(image1[meet11,]);row2=min(image1[meet12,]);row5=min(image1[meet13,]);row10=mean(image1[meet14,]);row11=min(image1[meet15,])
  meanval=(row1+row2+row5+row10+row11)/5
  mini=meanval; 
  d=0
  if (Threshold==0) d=0
  if (Threshold>0) d=Threshold
  Threshold=as.numeric(Threshold); mini=as.numeric(mini); d=as.numeric(d)
  totalthres=mini+d
  image1[image1>totalthres+0.1]=1
  image1[image1<1]=0
  y3=writePNG(image1); y4=readPNG(y3); y4[y4>0]=1; y4[y4==0]=2; y4[y4==1]=0; y4[y4==2]=1; 
  display(image, title="original image"); display(y4, title="image with threhold set"); 
  # Saving to global enviroment
  y4<<-y4; sprintf("$%.2f", y4); ### needed later?
  mini<<-mini; sprintf("$%.2f", mini); ### needed later?
  framenr<<-framenr; sprintf("%.2f", framenr); ### needed later?
  totalthres<<-totalthres; sprintf("$%.2f", totalthres); ### needed later?
}
