
#### function 4
divideResults <- function(step3,adjustdivision){
  # using right input image, depending if step 3 was skipped or not, 1 means used (y5 is result step 3)
  if (step3==0) qwe=y4; if (step3==1) qwe=y5 
  # finding border between patches of one or two birds
  LabelFIN=ConnCompLabel(qwe);stats = PatchStat(LabelFIN)
  stats = stats[stats[,2]<maxsize,] # getting rid of background stats
  mostcommon2=sort(table(stats$n.cell),decreasing=TRUE)[1:35]; 
  most2=as.matrix(mostcommon2); mat=as.numeric((rownames(most2))); maxmost=max(mat, na.rm=TRUE); 
  hist(stats[,2],main = paste("distribution of remaining patches"),
       xlab = "patch size in number of pixels",xlim=c(1,(round(maxmost*1.4))))
  textend1="value for dividing patches"; endresult1=maxmost
  print(as.vector(cbind(textend1,endresult1)))
  # dividing patches in tables
  qq=0
  if (adjustdivision==0) qq=maxmost
  if (adjustdivision!=0) qq=adjustdivision
  stats2 = stats[stats[,2]<qq,] # table with all one bird patches
  stats3 = stats[stats[,2]>qq,] # table with patches consisting of multiple birds
  # visualizing patches of two or more birds
  LabelFIN2 = ConnCompLabel(qwe);
  zNID = stats2[,1]; zEnd=length(zNID); 
  for (zw in 1:(zEnd-1))
  {LabelFIN2[LabelFIN2==(stats2[zw,1])] = 0};
  LabelFIN2[LabelFIN2>1]=1; 
  ff2=Image(LabelFIN2, colormode=Grayscale)
  # visualizing patches of single birds
  LabelFIN3 = ConnCompLabel(qwe);
  zNID = stats3[,1]; zEnd=length(zNID); 
  for (zw in 1:(zEnd-1))
  {LabelFIN3[LabelFIN3==(stats3[zw,1])] = 0};
  LabelFIN3[LabelFIN3>1]=1; 
  ff3=Image(LabelFIN3, colormode=Grayscale); 
  # Visualizing end result 
  allFiles=list.files(path=paste(direcPictures,sep='')) 
  allFiles=as.matrix(allFiles); 
  a=as.integer(image_to_open)
  imagename=allFiles[a,]
  image=readImage(paste(direcPictures,'/',imagename,sep=''))
  colorMode(ff3) = Grayscale; colorMode(ff2) = Grayscale; 
  x3=paintObjects(ff3, image, opac=c(1,1),col=c('red'),thick=TRUE, closed=FALSE)
  x4=paintObjects(ff2, x3, opac=c(1,1),col=c('blue'),thick=TRUE, closed=FALSE)
  display(x4, title="end result"); 
  amounttwo=length(stats3[,2]); amountone=length(stats2[,2])
  totalamount=amounttwo*2+amountone; 
  textend="number of birds counted ="; endresult=totalamount
  as.vector(cbind(textend,endresult))
}