
#### function 3
backgroundObjects <- function(maxsize,minsize){
  # Load image again (normal threshold)
  allFiles=list.files(path=paste(direcPictures,sep='')) 
  allFiles=as.matrix(allFiles); 
  a=as.integer(image_to_open)
  imagename=allFiles[a,]
  image=readImage(paste(direcPictures,'/',imagename,sep=''))
  image1=image[,,1]; image2=image[,,2]; image3=image[,,3]
  # threshold certain layer automatic (most clear layer picked automatically as well)
  med1=sd(image1);med2=sd(image2);med3=sd(image3);
  medtot=cbind(med1,med2,med3); medmax=min(medtot); framenr=which(medtot[1,]==medmax)
  image1=image[,,framenr]
  totalthres=as.numeric(totalthres)
  totalthres2=totalthres+0.17
  image1[image1>totalthres2]=1
  image1[image1<1]=0
  y3=writePNG(image1); yy4=readPNG(y3); yy4[yy4>0]=1; yy4[yy4==0]=2; yy4[yy4==1]=0; yy4[yy4==2]=1; 
  # Default mechanism
  d=0; if (maxsize==0) d=200;if (maxsize>0) d=maxsize
  u=0; if (minsize==0) u=0;if (minsize>0) u=maxsize
  # background creation
  LabelFIN=ConnCompLabel(yy4);stats = PatchStat(LabelFIN);
  stats = stats[stats[,2]<1000,]
  par(mfrow=c(1,1))
  hist(stats[,2],main = paste("distribution of remaining patches"),xlab = "patch size in number of pixels",xlim=c(1,200) )
  stats = stats[stats[,2]<d,] # getting rid of background stats
  stats = stats[stats[,2]>u,] # getting rid of noise
  stats4 = stats[stats[,2]<10000,] # table with patches consisting of background objects
  LabelFIN4 = ConnCompLabel(yy4);
  zNID = stats4[,1]; zEnd=length(zNID); 
  for (zw in 1:(zEnd-1))
  {LabelFIN4[LabelFIN4==(stats4[zw,1])] = 0};
  LabelFIN4[LabelFIN4>1]=1; 
  display(LabelFIN4, title="unwanted backgroud objects"); 
  # subtraction of background
  ff4=Image(LabelFIN4, colormode=Grayscale); y5=y4-LabelFIN4; display(y5, title="objects of interest remaining")
  # Saving to global enviroment
  y5<<-y5; sprintf("$%.2f", y5); ### needed later?
  totalthres<<-totalthres; sprintf("$%.2f", totalthres); ### needed later?
}

